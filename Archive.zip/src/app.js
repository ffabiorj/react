'use strict'

import React from 'react'


const App = React.createClass({
    render: function() {
        return <div>Aplicação</div>
    }
})

export default App